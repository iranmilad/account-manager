<div>
    <?php $__env->startSection("js"); ?>
    <script>
        Alarm({
            msg: "<?php echo e($msg); ?>",
            title: "<?php echo e($title); ?>",
            type: "<?php echo e($type); ?>",
            closeButton: "<?php echo e($closeButton); ?>",
            debug: "<?php echo e($debug); ?>",
            newestOnTop: "<?php echo e($newestOnTop); ?>",
            progressBar: "<?php echo e($progressBar); ?>",
            positionClass: "<?php echo e($positionClass); ?>",
            preventDuplicates: "<?php echo e($preventDuplicates); ?>",
            onclick: "<?php echo e($onclick); ?>",
            showDuration: "<?php echo e($showDuration); ?>",
            hideDuration: "<?php echo e($hideDuration); ?>",
            timeOut: "<?php echo e($timeOut); ?>",
            extendedTimeOut: "<?php echo e($extendedTimeOut); ?>",
            showEasing: "<?php echo e($showEasing); ?>",
            hideEasing: "<?php echo e($hideEasing); ?>",
            showMethod: "<?php echo e($showMethod); ?>",
            hideMethod: "<?php echo e($hideMethod); ?>"
        })
    </script>
    <?php $__env->stopSection(); ?>
</div><?php /**PATH Z:\holoo-manager\resources\views/components/alarm.blade.php ENDPATH**/ ?>