<?php if (isset($component)) { $__componentOriginal65e0bd0aeed8a21b598c76606db79d38 = $component; } ?>
<?php $component = App\View\Components\Main::resolve(['title' => 'پیام ها','icon' => '/assets/media/icons/messages.png'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <ul class="nav nav-tabs nav-pills  border-0 mb-5 fs-6">
    <li class="nav-item">
      <a class="nav-link btn btn-sm btn-active-primary active" data-bs-toggle="tab" href="#all_messages">همه</a>
    </li>
    <li class="nav-item">
      <a class="nav-link btn btn-sm btn-active-primary" data-bs-toggle="tab" href="#unseen_messages">خوانده نشده</a>
    </li>
    <li class="nav-item">
      <a class="nav-link btn btn-sm btn-active-primary" data-bs-toggle="tab" href="#seen_messages">خوانده شده</a>
    </li>
  </ul>

  <div class="tab-content" id="messages_content">
    <div class="tab-pane fade show active" id="all_messages" role="tabpanel"></div>
    <div class="tab-pane fade" id="seen_messages" role="tabpanel"></div>
    <div class="tab-pane fade" id="unseen_messages" role="tabpanel"></div>
  </div>
  <?php $__env->startSection('js'); ?>
  <script>
    Messages();
  </script>
  <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65e0bd0aeed8a21b598c76606db79d38)): ?>
<?php $component = $__componentOriginal65e0bd0aeed8a21b598c76606db79d38; ?>
<?php unset($__componentOriginal65e0bd0aeed8a21b598c76606db79d38); ?>
<?php endif; ?><?php /**PATH Z:\holoo-manager\resources\views/messages.blade.php ENDPATH**/ ?>