<?php if (isset($component)) { $__componentOriginal65e0bd0aeed8a21b598c76606db79d38 = $component; } ?>
<?php $component = App\View\Components\Main::resolve(['title' => 'گزارش گیری اشکالات','icon' => './assets/media/icons/findoption.png'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <!-- START:CARD -->
  <div class="card mb-5 mb-xl-10">
    <div class="card-header border-0">
      <div class="card-title m-0">
        <h3 class="fw-bold m-0">سرویس ابری</h3>
      </div>
    </div>
    <div class="card-body border-top p-9">
      <div class="d-flex flex-column justify-content-center container-fluid">
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>گزارش اتصال به لایسنس</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-check-circle fs-1 text-success" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>گزارش دریافت کالا ها</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-check-circle fs-1 text-success" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>گزارش حساب ها</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-check-circle fs-1 text-success" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>اتصال حساب ها</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-cross-circle fs-1 text-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
      </div>
    </div>
  </div>
  <!-- END:CARD -->
  <!-- START:CARD -->
  <div class="card mb-5 mb-xl-10">
    <div class="card-header border-0">
      <div class="card-title m-0">
        <h3 class="fw-bold m-0">گزارش فروشگاه کاربر</h3>
      </div>
    </div>
    <div class="card-body border-top p-9">
      <div class="d-flex flex-column justify-content-center container-fluid">
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>دسترسی به فروشگاه کاربر</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-check-circle fs-1 text-success" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
        <!-- START:ITEM -->
        <div class="row my-3">
          <div class="col-10">
            <span>دریافت کالاهای فروشگاه کاربر</span>
          </div>
          <div class="col-2">
            <i class="ki-duotone ki-cross-circle fs-1 text-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="متن راهنما">
              <span class="path1"></span>
              <span class="path2"></span>
            </i>
          </div>
        </div>
        <!-- END:ITEM -->
      </div>
    </div>
  </div>
  <!-- END:CARD -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65e0bd0aeed8a21b598c76606db79d38)): ?>
<?php $component = $__componentOriginal65e0bd0aeed8a21b598c76606db79d38; ?>
<?php unset($__componentOriginal65e0bd0aeed8a21b598c76606db79d38); ?>
<?php endif; ?><?php /**PATH Z:\holoo-manager\resources\views/issuereporting.blade.php ENDPATH**/ ?>